//CONTROLADOR 

//CONTIENE TODOS LOS METODOS POST Y GET QUE SELLAMAN DEL LADO DEL CLIENTE
//SE HIZO USO DE EXPRESS PARA REALIZAER EL WEBSERVICES TIPO REST

var burs = [];//arreglo donde se almacenan los burstime
var extraburs = [];//arreglo auxiliar para salvar los resultados del primer arreglo
var arrib = [];//arreglo que contiene los arribos
const express = require('express');//se imports la libreria express se define que es neceswria
const app = express();//se inicializa express
var fs = require('fs');//permite la lectura de csv
var csv = require('fast-csv');//es como la libreria 

var bodyParser = require('body-parser');//permite convertir los archivos json que se reciben en los metodos post
app.use(bodyParser.urlencoded({ extended: false }));//se usa
app.use(bodyParser.json());//se inicializa el bodyparser para que se use cada vez que se mencione

//para poder permitir el acceso al web services de todos los origenes sin esto no funciona
app.use(function (req, res, next) {//permite que se puedan conectar al web services desde cualquier aplicacion 
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

const Json2csvParser = require('json2csv').Parser;//permite convertir JSON a csv
const fields = ['Processes.id', 'Processes.burstTime', 'Processes.arribo'];

//POST: csv
//metodo post generarl que hace llamada a todos los metodos 
//en caso de que el usuario quiera comparar todos al mismo tiempo
app.post('/', (req, res) => {
  var obj = {};
  console.log('body: ' + JSON.stringify(req.body));
  var felicidad = req.body;//contiene lo que se recibe del cliente
  for (x = 0; x < felicidad.length; x++) {
    burs.push(felicidad[x].burstTime);//se guardan los valores obtenidos  en los rreglos locales
    arrib.push(felicidad[x].arribo);//se guardan los valores obtenidos  en los rreglos locales
  }
  Round(1, burs);
  res.send(concat);//lo que se retorna al cliente
});


//POST: fcfs apropiativo
app.post('/fcfs', function (req, res) {
  var felicidad = req.body;//contiene lo que se recibe del cliente
  console.log("Aqui debo imprimir: ");
  for (x = 0; x < felicidad.length; x++) {
    burs.push(parseInt(felicidad[x].burstTime));//se guardan los valores obtenidos  en los rreglos locales
    arrib.push(parseInt(felicidad[x].arribo));//se guardan los valores obtenidos  en los rreglos locales
  }
  console.log(FCFS(arrib, burs)); //imprimir 
  var all = []; //array all
  all[0] = "FCFS"; // se manda el titulo
  all[1] = "NUEVO: " + '\n' + nuevof + '\n'; //se manda el estado nuevo
  all[2] = "LISTO: " + '\n' + listof + '\n'; //se manda el estado listo
  all[3] = "EJECUCION: " + '\n' + ejecucionf + '\n'; //se manda el estado ejecucion
  all[4] = "TERMINADO: " + '\n' + terminadof + '\n'; //se manda el estado terminado
  all[5] = "TIEMPO PROMEDIO: " + '\n' + tiempopromediof + '\n'; //se manda el tiempo promedio
  all[6] = "TIEMPO ESPERA: " + '\n' + tesperaf + '\n'; //se manda el tiempo de espero
  ceroagain(); //se llama esta funcion para reinicializar todo
  res.send(all);//lo que se retorna al cliente
});
//POST:  apropiativo
app.post('/sjfap', function (req, res) {
  var felicidad = req.body;//contiene lo que se recibe del cliente
  for (x = 0; x < felicidad.length; x++) {
    burs.push(parseInt(felicidad[x].burstTime));//se guardan los valores obtenidos  en los rreglos locales
    arrib.push(parseInt(felicidad[x].arribo));//se guardan los valores obtenidos  en los rreglos locales
  }
  SJFA(arrib, burs, arrib.length); //funcion de apropiativo
  var all = []; //arreglo all
  all[0] = "SJFA"; //titulo
  all[1] = "NUEVO: " + '\n' + nuevoa + '\n'; //se envia la informacion de nueo
  all[2] = "LISTO: " + '\n' + listoa + '\n'; //se envia la informacion de listo
  all[3] = "EJECUCION: " + '\n' + concatenar + '\n'; //se enviar la informacion de ejecucion
  all[4] = "TERMINADO: " + '\n' + terminadoa + '\n'; //se envia la inormacion de terminado
  all[5] = "BLOQUEADO: " + '\n' + bloqueadoa + '\n'; //se envia la informacion de bloqueado
  all[6] = "TIEMPO ESPERA: " + '\n' + tesperaa + '\n'; //se envia la informacion de tiempo de espera
  all[7] = "PROMEDIO: " + '\n' + promedioa + '\n'; //se envia el promedio
  ceroagain(); //metodo que inicializa todo

  res.send(all);//lo que se retorna al cliente
});

//POST: no apropiativo
app.post('/cc', function (req, res) { //post
  var felicidad = req.body; //obtener el  body
  for (x = 0; x < felicidad.length; x++) {//contiene lo que se recibe del cliente
    burs.push(parseInt(felicidad[x].burstTime));//se guardan los valores obtenidos  en los rreglos locales
    arrib.push(parseInt(felicidad[x].arribo));//se guardan los valores obtenidos  en los rreglos locales
  }
  console.log(burs); //imprime el burst time
  console.log(arrib); // imprime el arribo
  SJFNA(arrib, burs); //llamada a la funcion de no apropiativo
  var all = []; //arreglo all 
  all[0] = "NO APROPIATIVO"; //titulo
  all[1] = "TIEMPO ESPERA: " + '\n' + tesperan + '\n'; //se envia el tiempo de espera
  all[2] = "NUEVO: " + '\n' + nuevo + '\n'; //se envia el nuevo
  all[3] = "LISTO: " + '\n' + listo + '\n'; //se envia el listo
  all[4] = "EJECUCION: " + '\n' + ejecucion + '\n'; //se envia el ejecucion
  all[5] = "TERMINADO: " + '\n' + terminado + '\n'; //se envia terminado
  all[6] = "TIEMPOPROMEDIO" + '\n' + promediona + '\n'; //se envia el promedio
  ceroagain(); //metodo que inicializa todo
  res.send(all);//lo que se retorna al cliente
});

//POST: HRRN 
app.post('/hrrn', function (req, res) { //post
  var felicidad = req.body; //se obtiene el body o request
  for (x = 0; x < felicidad.length; x++) {//contiene lo que se recibe del cliente
    burs.push(parseInt(felicidad[x].burstTime));//se guardan los valores obtenidos  en los rreglos locales
    arrib.push(parseInt(felicidad[x].arribo));//se guardan los valores obtenidos  en los rreglos locales
  }
  Hrrn(arrib, burs); //se llama a la funcion
  var all = []; //arreglo all
  all[0] = "HRRN"; //titulo
  all[1] = "TIEMPO ESPERA: " + '\n' + tespera + '\n'; //se envia el tiempo de espera
  all[2] = "NUEVO: " + '\n' + nuevoh + '\n'; //se envia el nuevo
  all[3] = "LISTO: " + '\n' + listoh + '\n'; //se envia el listo
  all[4] = "EJECUCION: " + '\n' + concatenando + '\n'; //se envia el ejecutado
  all[5] = "TERMINADO: " + '\n' + terminadoh + '\n'; //se envia terminado
  all[6] = "TIEMPOPROMEDIO" + '\n' + prom + '\n'; //se envia el tiempo promedio
  ceroagain(); //funcion que inicializa todo
  res.send(all); // lo que retorna al cliente
});
//POST: RoundRobin
app.post('/rr', function (req, res) { //post
  var felicidad = req.body;//se guardan los valores obtenidos  en los rreglos locales
  for (x = 0; x < felicidad.length; x++) {
    burs.push(parseInt(felicidad[x].burstTime));//se guardan los valores obtenidos  en los rreglos locales
    extraburs.push(parseInt(felicidad[x].burstTime));//se guardan los valores obtenidos  en los rreglos locales
    arrib.push(parseInt(felicidad[x].arribo));//se guardan los valores obtenidos  en los rreglos locales
  }
  var all = []; //array 
  bqquantum(extraburs); //funcion que calculo el busrt time
  RoundRobin(bestquantum, burs); // fucion del procedimiento de round robin
  all[0] = "ROUND ROBIN" //titulo
  all[1] = "LISTO: " + '\n' + listorr + '\n'; //se envia el listo
  all[2] = "EJECUCION: " + '\n' + concat + '\n'; //se envia la info de ejecucion
  all[3] = "TERMINADO: " + '\n' + terminadorr + '\n'; //se envia la infor de terminado
  all[4] = "BEST CUANTUM: " + '\n' + bestquantum + '\n'; //se envia la info de best cuantum
  all[5] = "CAMBIO CONTEXTOS: " + '\n' + cambiocontexto + '\n'; //se envia la informacion de cambio de contexto
  ceroagain(); // la funcion que inicializa todo
  res.send(all);//lo que se retorna al cliente
});

function ceroagain() { //esta funcion simplemente inicializa todo
  burs = []; //array del bust time
  arrib = []; //array para el tiempo de arribo

  nuevof = ""; //inicializacion de la variable
  listof = ""; //inicializacion de la variable
  ejecucionf = ""; //inicializacion de la variable
  terminadof = ""; //inicializacion de la variable
  tiempopromediof = ""; //inicializacion de la variable
  tesperaf = ""; //inicializacion de la variable

  nuevo = ""; //inicializacion de la variable
  tesperan = ""; //inicializacion de la variable
  listo = ""; //inicializacion de la variable
  ejecucion = ""; //inicializacion de la variable
  terminado = ""; //inicializacion de la variable
  promediona = ""; //inicializacion de la variable
  
  tespera = ""; //inicializacion de la variable
  nuevoh = ""; //inicializacion de la variable
  listoh = ""; //inicializacion de la variable
  concatenando = ""; //inicializacion de la variable
  terminadoh = ""; //inicializacion de la variable
  prom = "" //inicializacion de la variable

  listorr = ""; //inicializacion de la variable
  concat = ""; //inicializacion de la variable
  terminadorr = ""; //inicializacion de la variable
  bestquantum = ""; //inicializacion de la variable

}

//LISTENER de la conexion
//Es donde se conecta y donde estara corriendo nuestro WEB SERVICES
app.listen(3011, function (err) { //Listining the API
  if (err) { //In case of error
    console.log(err);
  } else {
    //RoundRobin(40,[40,20,80,10,54,10]);
    //console.log(concat);
    console.log("Estoy  funcionando");
  }
});

//////////////////////////////////////////LECTURA DE CSV

function fe() {//permite la lectura de archivos csv y guarda la informacion en una variable data
  fs.createReadStream('Fe.csv')//archivo que se va a leer
    .pipe(csv())
    .on('data', function (data) {
      processData(data);//este metodo se encarga de pasar el csv a arreglos para usarlo en los algoritmos de planificacion
    })
    .on('end', function (data) {
      //esta funcion finaliza la lectura del archivo
    });
}

function validarSiNumero(numero) { //funcion que valida los numeros
  var num = parseInt(numero); //parse al numero
  if (!/^([0-9])*$/.test(num)) { //exprecion regular
    return false; //retorna resultado false
  } else { //de lo contrario
    return true; //retorna resultado true
  }
}
// Let's process the data from the data file
//Este metodo convierte el csv y lo pasa a arreglos
function processData(data) { 
  var fe = String(data);
  var lines = fe.split('\n');//se divide linea a linea

  //Set up the data arrays
  var proceso = [];
  var burstime = [];
  var arribo = [];

  var headings = lines[0].split(','); // Splice up the first row to get the headings
  for (var i = 0; i < lines.length; i++) {
    var values = lines[i].split(',');//se separa por comas para guardar los valores en cada indice diferente
    proceso.push(values[0] + ',');
    if (validarSiNumero(values[1]) != false) {
      burstime.push(values[1] + ',');
    }
    if (validarSiNumero(values[2]) != false) {//son estos los estoy probando todavia
      arribo.push(values[2] + ',');
    }
  }
  for (var i = 0; i < burstime.length; i++) {
    var fe = burstime[i].split(',');
    var fe2 = arribo[i].split(',');
    extraburs.push(parseInt(fe[i]));//se ingresan los valores al arreglo local
    burs.push(parseInt(fe[i]));//se ingresan los valores al arreglo local
    arrib.push(parseInt(fe2[i]));//se ingresan los valores al arreglo local
  }
}




////////////////////////////////////////////////////////////////ALGORITMOS DE PLANIFICACION

//FCFS Aqui empieza


function Llenar(bt) { //funcion que lleva termporalmente
  for (var i = 0; i < bt.length; i++) { //recorre el busrt time array
    temporal = bt[i]; //guarda en un array aux.
  }
}
function Volver(arr) { //funcin volver
  for (var i = 0; i < arr.length; i++) { //reccorre
    burs = arr[i]; //devuelve los datos
  }
}
//function that gets the arrivalTime and burstTime (array)
var nuevof = ''; //inicializacion de la variable
var listof = ''; //inicializacion de la variable
var ejecucionf = ''; //inicializacion de la variable
var terminadof = ''; //inicializacion de la variable
var tesperaf = ''; //inicializacion de la variable
var tiempopromediof = 0; //inicializacion de la variable
var temporal = []; //declara array
//FCFS Aqui empieza

//intentional for the purpose of making qu globally scoped at function CT
let qu = 0;

//function that gets the arrivalTime and burstTime (array)
function FCFS(arrivalTime, burstTime) { //metodo del FCFS
  let output = 'P\tAT\tBT\tCT\tTT\tWT\n', //input
    objCollection = [], //array
    AT = [], //array
    BT = [], //array
    completion, //declara
    turnaround, //declara
    waiting, //declara
    att = [], //array
    awt = []; //array
  var list = 0;

  //guarda el arribo y busrt time
  for (var x = 0; x < arrivalTime.length; x++)
    objCollection.push({ A: arrivalTime[x], B: burstTime[x] });

  //hace un sort 
  objCollection.sort(function (a, b) {
    return a.A - b.A; //retorna
  });
  for (var x = 0; x < arrivalTime.length; x++) { //recorre
    nuevof += "P" + (x + 1) + " : " + arrivalTime[x] + "| "; // los procesos en estado nuevo
  }

  listof = "P1" + " : " + arrivalTime[0] + "| "; //los procesos en estado listo
  ejecucionf = "P1" + ": " + arrivalTime[0] + "--->";//los procesos en estado ejecucion
  for (var x = 0; x < objCollection.length; x++) { //recorre
    //guarda en el array de objetos
    AT.push(objCollection[x].A);
    BT.push(objCollection[x].B);
    ;
    if (x != 0) { //diferente de 0
      list += burs[x]; //guarda en una auxiliar
      listof += "P" + (x + 1) + " : " + (list) + "| "; //obtiene el proceso con estado listo
    }
    if (x == 0) {
      ejecucionf += burs[x];
    } else {
      ejecucionf += "P" + (x + 1) + " : " + completion + "--->" + (completion + burs[x]) + "| ";
    }
    completion = CT(BT[x]);
    turnaround = TT(completion, AT[x]);
    waiting = WT(turnaround, BT[x])
    tesperaf += "p" + (x + 1) + ": " + waiting + "| ";
    terminadof += "P" + (x + 1) + " : " + completion + "| ";
    //guarda el resultado
    output += `${x + 1}\t${AT[x]}\t${BT[x]}\t${completion}\t${turnaround}\t${waiting}\n`;

    //arreglos auxiliares
    att.push(turnaround);
    awt.push(waiting);
  }

  //pasa el arrivo y busrt time a la funcion y obtiene el resultado
  output += `Average Turnaround Time: ${averageTT(att, objCollection.length)}\nAverage Waiting Time: ${averageWT(awt, objCollection.length)}`
  tiempopromediof = averageWT(awt, objCollection.length);
  return output;
}

//Calcula el tiempo
function CT(bt) {

  qu += bt;
  return qu;
}

//Calcula el ta
function TT(ct, at) {
  return ct - at;
}

//calcula el wt
function WT(tt, bt) {
  return tt - bt;
}

//ccalcula el wt y ta usando este metodo de suma
function averageTT(ttValues, noOfValues) {
  return ttValues.reduce(function (total, num) {
    return total + num;
  }) / noOfValues;
}
//ccalcula el wt y ta usando este metodo de suma
function averageWT(wtValues, noOfValues) {
  return wtValues.reduce(function (total, num) {
    return total + num;
  }) / noOfValues;
}


//ROUND ROBIN

//declara las variables y algunas las inicializa
var finalizado = false;
var valprint = 0;
var auxvalprint = 0;
var concat = '';
var listorr = '';
var terminadorr = '';
var bloqueadorr
var bestquantum;
var cambiocontexto = 0;
function RoundRobin(quantum, valburs) { //funcion que hace el proceso de ROund roBIN
  Llenar(valburs); //LLENA
  var x = 0; //INICIALIZA
  var anterior; //declara
  while (finalizado === false) { //mientras no se alla finalizadi
    for (var x = 0; x < valburs.length;) { //recorre
      if (valburs[x] <= quantum) { //pregunta si alcalza el quantum
        if (valburs[x] != 0) { //si el bust no es 0
          auxvalprint = valprint; 
          valprint += valburs[x];
          valburs[x] = 0; //guarda 0
          concat = concat + ('p' + (x + 1) + ':' + auxvalprint + '->' + valprint + '|'); //obtiene los procesos
          listorr += ('p' + (x + 1) + ':' + auxvalprint + '| '); //obtiene los procesos ene stado listo
          terminadorr += ('p' + (x + 1) + ':' + valprint + '| '); //obtiene los procesos en estado terminado
          finalizado = false; //aun no finaliza
          if (finalizado === false) { //pergunta si no ha finalizado
            x++; //continua
          }
          if (anterior != (x + 1)) { //si no es como el siguiente
            cambiocontexto += 1; //aumenta
          }
        } else { //de lo contrario
          x++; // aumnta
          finalizado = true; //termina
        }
      } else { //en caso contrario
        if (valburs[x] != 0) { //si el busrt no es 0
          valburs[x] = valburs[x] - quantum; 
          auxvalprint = valprint;
          valprint += quantum; //concatena el quatum
          concat = concat + ('p' + (x + 1) + ':' + auxvalprint + '->' + valprint + '|'); //obtiene el proceso
          listorr += ('p' + (x + 1) + ':' + auxvalprint + '| '); //obtiene el listo
          terminadorr += ('p' + (x + 1) + ':' + valprint + '| '); //obtiene el proceso terminado
          finalizado = false; //no finaliza
          if (finalizado === false) { //no ha finalizado
            x++; //aumenta
          }
          if (anterior != (x + 1)) { //compara el con sig.
            cambiocontexto += 1; //aumente
          }
        } else { //de contrario
          x++; //aumenta
          finalizado = true;//termina
        }
      }
    }
  }
  for (var i = 0; i < valburs.length; i++) { //recorre
    if (valburs[i] != 0) { // si no es 0
      finalizado = false; //no finaliza
      RoundRobin(20, valburs); //llama a la funcion round robin
    }
  }
}
//se usa un ciclo burbuja para el proceso
//esta funcion hace el ciclo burbuja
function burbuja(v) {
  var n = v.length;
  var aux = 0;
  for (var i = 0; i < n - 1; i++) {
    for (var j = i + 1; j < n; j++) {
      if (v[i] > v[j]) {
        aux = v[j];
        v[j] = v[i];
        v[i] = aux;
      }
    }
  }
}
var temp0 = 0;

//fucion que calcula la mediana
function mediana(burstime) {
  burbuja(burstime);
  var numElementos = burstime.length
  var mediana;
  if (numElementos % 2 == 0) {
    var sumaMedios = burstime[numElementos / 2] + burstime[numElementos / 2 - 1];
    mediana = sumaMedios / 2;
  } else {
    mediana = burstime[numElementos / 2];
  }
  temp0 = mediana;
  return mediana;
}

//funcion que calcula el quatum
function bqquantum(burs) {
  var media = 0;
  for (var i = 0; i < burs.length; i++) {
    media += burs[i];
  }
  media = media / burs.length;
  mediana(burs);
  bestquantum = (media + temp0) / 2;
  console.log('El best quantum es: ' + bestquantum);
}

//funcion que hace todo lo que debe de tener round robin
function Round(quantum, burst) {
  RoundRobin(quantum, burst);
  bqquantum(burst);
  console.log(concat);
}

//HRRN
function Ordenar(arribo, tiempoburs) { //metodo que ordena
  for (var k = 0; k < arribo.length; k++) { 
    for (var f = 0; f < arribo.length - 1 - k; f++) {
      //ciclos anidados
      if (arribo[f] > arribo[f + 1]) { //compara el actual con el siguiente
        var auxarribo; //declara variable
        auxarribo = arribo[f]; //asgina
        arribo[f] = arribo[f + 1];
        arribo[f + 1] = auxarribo;
        var auxburs;
        auxburs = tiempoburs[f];
        tiempoburs[f] = tiempoburs[f + 1];
        tiempoburs[f + 1] = auxburs;
      }
    }
  }
}

//HRRN
var wait = []; //declara array
var prom = 0; //inicializa
var tespera = ''; //inicializa
function waittime() { //funcion que calcula el waiting time
  for (var i = 0; i < wait.length; i++) { //recorre
    prom += wait[i]; //se va guardando el waiting 
    tespera += " p" + (i + 1) + ":" + wait[i] + "|" // se obtiene el proceso en espera
    console.log(wait[i]); //se imprime
  }
  prom = prom / wait.length; //se calcula el promedio
  console.log('Promedio: ' + prom); // se imprime
}
//se inicializan las funciones
var lastburs = 0;
var actualw = 0;
var nuevoh = '';
var concatenando = '';
var terminadoh = '';
var auxlast = 0;
var noalosciclos = 0;
var listoh = '';
function Hrrn(arrivo, tiempoburs) { //funcion hrrn
  var times = []; //array de tiempo
  lastburs=0;
  auxlast=0;
  wait=[];
  Ordenar(arrivo, tiempoburs); //ordena el arrivo y el busrt tiem
  var l = 0; //inicializa
  wait[0] = 0; //inicializa
  //para que no se encicle solo en caso de emergencia
  for (var i = 0; i < tiempoburs.length; i++) { //recorre
    noalosciclos += tiempoburs[i]; //se asigna 
  }
  for (var i = 0; i < arrivo.length; i++) { //recorre
    nuevoh += ' |P' + (i + 1) + ' : ' + arrivo[i] + "| "; //se obtiene los procesos ene stado nuevo
  }
  lastburs = tiempoburs[0]; //el ultimo busrt tiem
  tiempoburs[0] = -1; //el tiempo se disminuye
  arrivo[0] = -1; //arribo disminuyendo
  var necesidad = 0; //inicializa
  listoh = ' P' + (l + 1) + ":" + auxlast + "| "; //obtiene el proceso en estado listo
  concatenando = concatenando + (' P' + (l + 1) + ':' + auxlast + '->' + lastburs + '| '); //obtiene el proceso e
  terminadoh += ' P' + (l + 1) + ":" + lastburs + "| "; //obtiene el proceso en estado terminado
  while (tiempoburs[l] != null) { //mientas el busrt tiem no sea nulo
    var mayor = 0; //inicializa
    auxlast = lastburs; //aux para el ultimo bust
    //hacer la operacion del HRRN
    for (var i = 0; i < tiempoburs.length; i++) { //recorre
      if (tiempoburs[i] != 0 && tiempoburs[i] != -1 && arrivo[i] <= auxlast) { //se compara
        //se hace el calculo para saber cual proceso continua
        actualw = auxlast - arrivo[i]; //
        times[i] = (actualw + tiempoburs[i]) / tiempoburs[i]
      } else {
        times[i] = 0;
      }
    }

    //buscar el mayor
    for (var j = 0; j < times.length; j++) {
      if (times[j] > mayor) {
        mayor = times[j];
      }
    }
    //siendo ineficiente para que funcione *3
    for (var j = 0; j < times.length; j++) {
      if (times[j] == mayor) {
        necesidad = tiempoburs[j]
        wait[j] = ((arrivo[j] - lastburs) * -1)
      }
    }
    //hacer cero el burstime del mayor
    for (var j = 0; j < times.length; j++) {
      if (times[j] == mayor) {

        tiempoburs[j] = 0;
      }
    }
    //
    for (var x = 0; x < tiempoburs.length; x++) { //recorre
      if (tiempoburs[x] === 0) { //cuando es 0
        lastburs = (auxlast + necesidad); //se obtiene el ultimo
        nuevo[x] = lastburs; //se obtiene el nuevo
        terminadoh += ' P' + (l + 1) + ":" + lastburs + "| "; //proceso en estado nuevo
        listoh += ' P' + (l + 1) + ":" + auxlast + "| "; //proceso en estado terminado
        concatenando = concatenando + (' P' + (x + 1) + ':' + auxlast + '->' + lastburs + '| '); //proceso 
        tiempoburs[x] = -1; //se disminute el busrt time
        arrivo[x] = -1; //se disminuye el arrivo
      }
    }
    for (var j = 0; j < times.length; j++) { 
      times[j] = 0; //se pone el tiempo en 0
    }
    if (noalosciclos === lastburs) {
      tiempoburs[l] = null;
    } else {
      l += 1;
    }
  }
  console.log('Waittime');//titulo
  console.log(concatenando); //imprime
  waittime(); //funcion que calcula el waiting time
}

//NO Apropiativo
//se inicializan las variables de los procesos y el promedio
var nuevo = "";
var listo = "";
var ejecucion = "";
var terminado = "";
var concatenar = "";
var tesperan = "";
var promediona = 0;
var avgwt = 0; var avgta = 0;
function SJFNA(Arrival, BurstTime) {
  var pid = new Array(); //Array con el ID de los procesos
  var at = new Array(); //Array con los tiempo de arrivo
  var bt = new Array(); //Array con el busttime
  var ct = new Array();
  var ta = new Array();
  var wt = new Array(); //Array con los tiempos de espera
  var f = new Array();
  var st = 0; //Tiempo de inicio
  var tot = 0; //Tiempo total
  var n = Arrival.length; //Cantidad de procesos
  //Todos nuevo ;)

  for (var i = 0; i < n; i++) { //recorre 
    at[i] = Arrival[i]; //se declara y se asigna el arrivo
    bt[i] = BurstTime[i] //se declara y se asigna el busrt tiem
    pid[i] = i + 1; //se obtiene el id del proceso
    f[i] = 0; //se inicializa
    nuevo += "P" + (i + 1) + " : " + Arrival[i] + "||" + '\n'; //linea obtiene el estado en nuevo
  }


  while (true) {
    var c = n; //A la variable C se le asigna la cantidad de procesos
    var min = 999; //Variable minimo (No estoy segura para que aun)
    if (tot === n) //
      break;

    for (var i = 0; i < n; i++) { //Busca el minimo
      if ((at[i] <= st) && (f[i] === 0) && (bt[i] < min)) { //compara
        min = bt[i]; //se obtiene el minimo
        c = i; //se obtiene el proceso

      }
    }

    if (c === n) { 
      st++;// aumenta el espacio o tiempo
    } else {

      ct[c] = st + bt[c]; //calcula
      st += bt[c]; //asigna el tiempo o espacio
      ta[c] = ct[c] - at[c];
      //ejecucion
      wt[c] = ta[c] - bt[c]; //calcula el watiintg time
      listo += "P" + (c + 1) + " : " + "" + (ct[c] - BurstTime[c]) + "||" + "\n"; //obtiene el estado listo
      f[c] = 1;//asigna
      tot++; //aumenta
      ejecucion += "P" + (c + 1) + " : " + "[ " + (ct[c] - BurstTime[c]) + " -- " + ct[c] + " ] ||"; //estado ejecucion
      concatenar += "P" + (c + 1) + " ---> " + ct[c] + ","; //obtiene los procesos 
      terminado += "P" + (c + 1) + " : " + ct[c] + "|| " + "\n"; //estado terminado
    }
  }


  for (var i = 0; i < n; i++) { //recorre
    tesperan += "P" + (i + 1) + " : " + wt[i] + "|| " + "\n"; //estado espera
    avgwt += wt[i]; //asigna valor
    avgta += ta[i]; //asigna valor

    //console.log(pid[i]+"\t"+at[i]+"\t"+bt[i]+"\t"+ct[i]+"\t"+ta[i]+"\t"+wt[i]);
  }

  //impresiones para saber los resultados que va a mostrar cuando consume el web service
  console.log(concatenar);
  console.log("")
  console.log(nuevo);
  console.log(listo);
  console.log(ejecucion);
  console.log(terminado); 

  console.log("\naverage tat is " + avgta / n); //imrpime
  promediona = avgwt / n; //calcula el promedio
  console.log("average wt is " + avgwt / n); //imprime el promedio del resultado segun el algoritmo 
  console.log("----------------------------") //imprime
}

//SJFA
var nuevoa = ""; //declara 
var listoa = ""; //declara
var ejecuciona = ""; //declara
var bloqueadoa = ""; //declara
var terminadoa = ""; //declara
var tesperaa = ""; //declara
var promedioa = ""; //declara
var anterior = 0; //declara
var nuevos = 0; //declara
var concatenar = ""; //declara
var traza = ""; //declara
var seDetuvo = 0; //declara
var promedioporproceso = ""; //declara
var cont = 0; //declara
function SJFA(Arrival, BurstTime, tam) { //inicia la funcion de SJF apropiativo
  var pid = new Array(); //declara
  var at = new Array(); //declara
  var bt = new Array(); //declara
  var ct = new Array(); //declara
  var ta = new Array(); //declara
  var wt = new Array(); //declara
  var f = new Array(); //declara
  var k = new Array(); //declara
  var st = 0; tot = 0; //declara
  var avgwt = 0, avgta = 0; //declara
  var n = tam; //declara


  var inefi = new Array(); //declara
  var inefi2 = new Array(); //declara
  var Trazo = new Array(); //declara


  for (var i = 0; i < n; i++) { //recorre
    pid[i] = i + 1; //declara y guarda valor
    at[i] = Arrival[i]; //declara y guarda valor
    bt[i] = BurstTime[i]; //declara y guarda valor
    procesos = new Array(); //declara 
    bloq = new Array(); //declara
    TimeBloq = new Array(); //declara
    Finalizo = new Array(); //declara


    pid[i] = i + 1; //asigna valor
    k[i] = bt[i]; //asigna valor
    f[i] = 0; //asigna valor
    nuevoa += "P" + (i + 1) + " || Estado: Nuevo: [ " + Arrival[i] + " ]" + '\n'; //se obtiene el estado nuevo
  }

  while (true) {
    ct[c]; //array
    anterior = c; //inicializa variable
    var c = n; min = 999; //declara variables
    if (tot === n) { //saber si ya todo termino
      break;
    }

    for (var i = 0; i < n; i++) { //Ciclo for para recorrer todos los procesos
      if ((at[i] <= st) && (f[i] === 0) && (bt[i] < min)) //Obtener el orden de los procesos
      {
        min = bt[i]; //minimo cambia
        c = i; //c ahora es i
        nuevos = i; //se sabe cual es el nuevo proceso
      }
    }
    traza += "P" + (nuevos + 1) + " || Traza: [ " + st + " ]" + '\n'; //se obtiene el trazo del proceso

    if (c == n) {
      st++; //aumenta el tiempo
      concatenar += "P" + (c + 1) + " ---> " + ct[c] + " "; //dibujar el diagrama de grantt
    }
    else {
      //aca se inicia a ejecutar
      if (bloq[c] === c && bt[c] !== 0) { 
        seDetuvo = st; //el tiempo en el que se detuvo
        inefi2[c] = seDetuvo; //guarda el tiempo;
      }

      bt[c]--; //aqui se le va disminuyendo e busrt - time;

      if (nuevos === procesos[c]) {
        //console.log("Proceso "+(procesos[c]+1)+" || Tiempo: "+st);
        Finalizo[c] = st; //se finalizaco el profeso
        inefi[c] = procesos[c]; //auxiliar para guardar los procesos
        procesos[c] = null; //cambiar los valores dentro del auxliar.

      } else {
        //console.log("proceso nuevo: "+(c+1));
      }

      st++; //aunmenta el start time

      if (nuevos === anterior && anterior !== undefined) { //que se alla cambiado de proceso


      } else {
        if (bt[anterior] === 0) { //que el proceso no alla termiando

        } else {
          if (anterior !== undefined) { //el proceso no esta indefinido
            traza += "P" + (nuevos + 1) + " || Traza: [ " + st + " ]" + '\n'; //se obtiene el trazo del proceso
            //concatenar += "P"+(c+1)+" ---> "+ ct[c] + " " ;
            bloq[anterior] = anterior //se guardan los procesos bloqueados
            TimeBloq.push(st - 1); //el tiempo en el que se bloquearon
            procesos[anterior] = anterior; //el proceso
            concatenar += "P" + (anterior + 1) + " ---> " + (st - 1) + " ";
          } else {

          }
        }
      }

      if (bt[c] == 0) // Si el proceso ya termino
      { //ocurre esto
        ct[c] = st; //se asigna el tiempo o espacio en donde esta el proceso
        concatenar += "P" + (c + 1) + " ---> " + ct[c] + " "; //se va dibujando el diagrama de Gantt
        f[c] = 1; //asigna 1
        tot++; //aunmenta

        listoa += "P" + (c + 1) + " || Estado: Listo [ " + Arrival[c] + " ]" + '\n'; //obtiene los procesos en estado listo

      }
    }

  }

  for (i = 0; i < n; i++) { //recorre
    ta[i] = ct[i] - at[i]; //calculo para ta
    wt[i] = ta[i] - k[i]; //hace el calculo para wt
    avgwt += wt[i]; //obtiene el wt (waiting time)
    tesperaa += "p" + (i + 1) + " : " + wt[i] + "| "; //en espera
    avgta += ta[i]; //obtener el ta
    terminadoa += "P" + (i + 1) + " || Estado: Terminado [ " + ct[i] + " ]" + '\n'; //estado terminado

    if (i < inefi.length) { //recorre
      //obtiene los procesos en estado listo
      listoa += "P" + (inefi[i] + 1) + " || Estado: Listo [ " + Finalizo[i] + " -- " + inefi2[i] + " ]" + '\n';
    }
  }


  for (i = 0; i < inefi.length; i++) { //recorre el array en donde tiene los procesos que han estado en bloquedo
//guarda el resultado para uso posterior
    bloqueadoa += "P" + (inefi[i] + 1) + " || Estado: Bloqueado: [" + TimeBloq[i] + " -- " + Finalizo[i] + " ] " + '\n';
  }
  console.log(concatenar); //imprime
  console.log(""); //espacio
  console.log(traza); //imprime
  console.log("");//espacio
  console.log(nuevoa) //imprime
  console.log(listoa); //imprime
  console.log(ejecuciona) //imprime
  console.log(bloqueadoa) //imprime
  console.log(terminadoa) //imprime
  promedioa = avgwt / n; //calcula el promedio
  console.log("\naverage tat is " + avgta / n); //imprime
  console.log("average wt is " + avgwt / n); //imprime
}

