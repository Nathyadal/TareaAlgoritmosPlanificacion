//////////////////////////////////////METODOS
////////////////////////////////////////////////////////////////ALGORITMOS DE PLANIFICACION


  
  //ROUND ROBIN
  var valprint = 0;
  var auxvalprint = 0;
  var concat = '';
  var listorr='';
  var bloqueadorr='';
  var terminadorr='';
  
  var bestquantum;
  var cambiocontexto = 0;
  function RoundRobin(quantum, valburs) {
    Llenar(valburs);
    var x = 0;
    var anterior;
    while (valburs[x] != null) {
      if (valburs[x] <= quantum) {
        if (valburs[x] != 0) {
          auxvalprint = valprint;
          valprint += valburs[x];
          valburs[x] = 0;
          listorr=('p' + (x + 1) + ':' + auxvalprint+ '| ');
          terminadorr=('p' + (x + 1) + ':' + valprint + '| ');
          concat = concat + ('p' + (x + 1) + ':' + auxvalprint + '->' + valprint + '|');
          if (anterior != (x + 1)) {
            cambiocontexto += 1;
          }
        }else{
          x+=1;
          if(x===valburs.length || valburs[x] != 0){
            x=0;
          }
        }
      } else {
        if (valburs[x] != 0) {
          valburs[x] = valburs[x] - quantum;
          auxvalprint = valprint;
          valprint += quantum;
          concat = concat + ('p' + (x + 1) + ':' + auxvalprint + '->' + valprint + '|');
          listorr+=('p' + (x + 1) + ':' + auxvalprint+ '| ');
          terminadorr+=('p' + (x + 1) + ':' + valprint + '| ');
          if (anterior != (x + 1)) {
            cambiocontexto += 1;
          }
        }else{
          x+=1;
          if(x===valburs.length){
            x=0;
          }
        }
      }
    }
    var i = 0;
    while (valburs[i] != 0) {
      RoundRobin(quantum, valburs);
      x=0;
      i += 1;
    }
  }
  
  function burbuja(v) {
    var n = v.length;
    var aux = 0;
    for (var i = 0; i < n - 1; i++) {
      for (var j = i + 1; j < n; j++) {
        if (v[i] > v[j]) {
          aux = v[j];
          v[j] = v[i];
          v[i] = aux;
        }
      }
    }
  }
  var temp0 = 0;
  function mediana(burstime) {
    burbuja(burstime);
    var numElementos=burstime.length
    var  mediana;
    if(numElementos % 2 == 0){
        var sumaMedios = burstime[numElementos/2] + burstime[numElementos/2 - 1]; 
        mediana = sumaMedios / 2; 
    } else {
        mediana = burstime[numElementos/2];
    }
    temp0=mediana;
    return mediana;
  }
  function bqquantum(burs) {
    var media = 0;
    for (var i = 0; i < burs.length; i++) {
      media += burs[i];
    }
    media = media / burs.length;
    mediana(burs);
    bestquantum = (media + temp0) / 2;
    console.log('El best quantum es: ' + bestquantum);
  }
  function Round(quantum, burst) {
    RoundRobin(quantum, burst);
    bqquantum(burst);
    console.log(concat);
  }
  
  //HRRN
  function Ordenar(arribo, tiempoburs) {
    for (var k = 0; k < arribo.length; k++) {
      for (var f = 0; f < arribo.length - 1 - k; f++) {
        if (arribo[f] > arribo[f + 1]) {
          var auxarribo;
          auxarribo = arribo[f];
          arribo[f] = arribo[f + 1];
          arribo[f + 1] = auxarribo;
          var auxburs;
          auxburs = tiempoburs[f];
          tiempoburs[f] = tiempoburs[f + 1];
          tiempoburs[f + 1] = auxburs;
        }
      }
    }
  }
  
  //HRRN
  var wait = [];
  var prom = 0;
  var tespera = '';
  function waittime() {
    for (var i = 0; i < wait.length; i++) {
      prom += wait[i];
      tespera += " p" + (i + 1) + ":" + wait[i] + "|"
      console.log(wait[i]);
    }
    prom = prom / wait.length;
    console.log('Promedio: ' + prom);
  }
  var lastburs = 0;
  var actualw = 0;
  var nuevoh = '';
  var concatenando = '';
  var terminadoh = '';
  var auxlast = 0;
  var noalosciclos = 0;
  var listoh='';
  function Hrrn(arrivo, tiempoburs) {
    var times = [];
    Ordenar(arrivo, tiempoburs);
    var l = 0;
    wait[0] = 0;
    //para que no se encicle solo en caso de emergencia
    for (var i = 0; i < tiempoburs.length; i++) {
      noalosciclos += tiempoburs[i];
    }
    for(var i = 0;i<arrivo.length;i++){
      nuevoh += ' |P' + (i + 1) + ' : ' + arrivo[i] + "| ";
    }
    lastburs = tiempoburs[0];
    tiempoburs[0] = -1;
    arrivo[0] = -1;
    var necesidad = 0;
    listoh=' P' + (l + 1) + ":" + auxlast + "| ";
    concatenando = concatenando + (' P' + (l + 1) + ':' + auxlast + '->' + lastburs + '| ');
    terminadoh += ' P' + (l + 1) + ":" + lastburs + "| ";
    while (tiempoburs[l] != null) {
      var mayor = 0;
      auxlast = lastburs;
      //hacer la operacion del HRRN
      for (var i = 0; i < tiempoburs.length; i++) {
        if (tiempoburs[i] != 0 && tiempoburs[i] != -1 && arrivo[i] <= auxlast) {
          actualw = auxlast - arrivo[i];
          times[i] = (actualw + tiempoburs[i]) / tiempoburs[i]
        } else {
          times[i] = 0;
        }
      }
  
      //buscar el mayor
      for (var j = 0; j < times.length; j++) {
        if (times[j] > mayor) {
          mayor = times[j];
        }
      }
      //siendo ineficiente para que funcione *3
      for (var j = 0; j < times.length; j++) {
        if (times[j] == mayor) {
          necesidad = tiempoburs[j]
          wait[j] = ((arrivo[j] - lastburs) * -1)
        }
      }
      //hacer cero el burstime del mayor
      for (var j = 0; j < times.length; j++) {
        if (times[j] == mayor) {
  
          tiempoburs[j] = 0;
        }
      }
      //
      for (var x = 0; x < tiempoburs.length; x++) {
        if (tiempoburs[x] === 0) {
          lastburs = (auxlast + necesidad);
          nuevo[x] = lastburs;
          terminadoh += ' P' + (l + 1) + ":" + lastburs + "| ";
          listoh+=' P' + (l + 1) + ":" + auxlast + "| ";
          concatenando = concatenando + (' P' + (x + 1) + ':' + auxlast + '->' + lastburs + '| ');
          tiempoburs[x] = -1;
          arrivo[x] = -1;
        }
      }
      for (var j = 0; j < times.length; j++) {
        times[j] = 0;
      }
      if (noalosciclos === lastburs) {
        tiempoburs[l] = null;
      } else {
        l += 1;
      }
    }
    console.log('Waittime');
    console.log(concatenando);
    waittime();
  }
  
  //NO Apropiativo
  var nuevo = "";
  var listo = "";
  var ejecucion = "";
  var terminado = "";
  var concatenar = "";
  var tesperan="";
  var promediona=0;
  var avgwt = 0; var avgta = 0;
  function SJFNA(Arrival, BurstTime) {
    var pid = new Array(); //Array con el ID de los procesos
    var at = new Array(); //Array con los tiempo de arrivo
    var bt = new Array(); //Array con el busttime
    var ct = new Array();
    var ta = new Array();
    var wt = new Array(); //Array con los tiempos de espera
    var f = new Array();
    var st = 0; //Tiempo de inicio
    var tot = 0; //Tiempo total
    var n = Arrival.length; //Cantidad de procesos
    //Todos nuevo ;)
  
    for (var i = 0; i < n; i++) {
      at[i] = Arrival[i];
      bt[i] = BurstTime[i]
      pid[i] = i + 1;
      f[i] = 0;
      nuevo += "P" + (i + 1) + " : " + Arrival[i] + "||" + '\n';
    }
  
  
    while (true) {
      var c = n; //A la variable C se le asigna la cantidad de procesos
      var min = 999; //Variable minimo (No estoy segura para que aun)
      if (tot === n) //
        break;
  
      for (var i = 0; i < n; i++) { //Busca el minimo
        if ((at[i] <= st) && (f[i] === 0) && (bt[i] < min)) {
          min = bt[i];
          c = i;
  
        }
      }
  
      if (c === n) {
        st++;
      } else {
  
        ct[c] = st + bt[c];
        st += bt[c];
        ta[c] = ct[c] - at[c];
        //ejecucion
        wt[c] = ta[c] - bt[c];
        listo += "P" + (c + 1) + " : " + "" + (ct[c] - BurstTime[c]) + "||" + "\n";
        f[c] = 1;
        tot++;
        ejecucion += "P" + (c + 1) + " : " + "[ " + (ct[c] - BurstTime[c]) + " -- " + ct[c] + " ] ||" + "\n";
        concatenar += "P" + (c + 1) + " ---> " + ct[c] + ",";
        terminado += "P" + (c + 1) + " : " + ct[c] + "|| " + "\n";
      }
    }
  
  
    for (var i = 0; i < n; i++) {
      tesperan+="P" + (i + 1) + " : " + wt[i] + "|| " + "\n";
      avgwt += wt[i];
      avgta += ta[i];
  
      //console.log(pid[i]+"\t"+at[i]+"\t"+bt[i]+"\t"+ct[i]+"\t"+ta[i]+"\t"+wt[i]);
    }
    console.log(concatenar);
    console.log("")
    console.log(nuevo);
    console.log(listo);
    console.log(ejecucion);
    console.log(terminado);
  
    console.log("\naverage tat is " + avgta / n);
    promediona=avgwt/n;
    console.log("average wt is " + avgwt / n);
    console.log("----------------------------")
  }
  
  //SJFA
  function SJFA(Arrival,BurstTime){
    var pid = new Array();
    var at = new Array();
    var bt = new Array();
    var ct = new Array();
    var ta = new Array();
    var wt = new Array();
    var f = new Array();
    var k = new Array(); 
    var st = 0; tot = 0;
    var avgwt=0, avgta=0;
    var n = Arrival.length;
  
    var nuevo = "";
    var listo = "";
    var ejecucion = ""
    var terminado = "";
  
  var feex2 = "";
  var traicion;
    for(var i =0; i < n; i++){
      pid[i] = i +1;
      at[i] = Arrival[i];
      bt[i] = BurstTime[i];
      auxB = new Array();
      pid[i] = i+1;
      k[i] = bt[i];
      f[i] = 0;
      nuevo += "P"+(i+1)+" || Estado: Nuevo: "+Arrival[i]+ " " + '\n';
    }
  
    while(true){
      var c =n; min =999;
      if(tot === n){
        break;
      }
  
      for(var i =0; i < n; i++){ //Ciclo for para recorrer todos los procesos
        if ((at[i] <= st) && (f[i] === 0) && (bt[i]<min)) //Obtener el orden de los procesos
        {
          min=bt[i];
          c=i;  
        }
    }
     
  
      if (c==n) 
                  st++;
              else
              {
                  bt[c]--; //aqui se le va disminuyendo e busrt - time;
            st++; //aunmenta el start time
                  if (bt[c]==0) // Si el proceso ya termino
                  { //ocurre esto
                      ct[c]= st;
                      f[c]=1;
                      tot++;
            }else{
            }
              }
    }
  
    for(i=0;i < n ;i++)
          {
              ta[i] = ct[i] - at[i];
              wt[i] = ta[i] - k[i];
              avgwt+= wt[i];
              avgta+= ta[i];
          }
  
        console.log("pid  arrival  burst  complete turn waiting");
          for(i=0;i < n;i++)
          {
              console.log(pid[i] +"\t"+ at[i]+"\t"+ k[i] +"\t"+ ct[i] +"\t"+ ta[i] +"\t"+ wt[i]);
          }
          
    console.log ("\naverage tat is "+avgta/n);
    console.log ("average wt is "+ avgwt/n);
  }


